<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$pairid=$_REQUEST['pair_id'];
	$userid=$_REQUEST['user_id'];
	$query="SELECT * FROM lonelymessages WHERE pair_id='".$pairid."'";
	$result=mysqli_query($connection,$query);
	if(mysqli_num_rows($result)){
		$rows=array();
		$seen=";".$userid.";";
		while($row=mysqli_fetch_assoc($result)){
			$rows[]=$row;
			if(strpos($row['seen'],$seen)===false){
				$seen=$seen.$row['seen'];
				$result_new=mysqli_query($connection,"UPDATE lonelymessages SET seen='".$seen."' WHERE message_id='".$row['message_id']."'");
			}
		}
		echo json_encode($rows);
	}
?>