<?php 
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$email=$_REQUEST['email'];
	$password=$_REQUEST['password'];
	str_replace("_"," ",$email);str_replace("_"," ",$password);
	$query="SELECT * FROM lonelyusers WHERE email LIKE '".$email."' AND password LIKE '".$password."'";
		$check=mysqli_query($connection,$query);
		$res=mysqli_num_rows($check);
		if($res>0){
			$updatequery="UPDATE lonelyusers SET lastseen='".$_SERVER['REQUEST_TIME']."' WHERE email LIKE '".$email."'";
			$update=mysqli_query($connection,$updatequery);
			$query="SELECT * FROM lonelyusers WHERE email LIKE '".$email."' AND password LIKE '".$password."'";
			$select=mysqli_query($connection,$query);
			$rows=array();
		while($row=mysqli_fetch_assoc($select))
			{
				$rows[]=$row;
			}
			echo json_encode($rows);
		}
		
?>