<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$message=$_POST['message'];
	$senderid=$_POST['sender_id'];
	$pairid=$_POST['pair_id'];
	$seen=";".$senderid.";";
	$timestamp=$_SERVER['REQUEST_TIME'];
	$query="INSERT INTO lonelymessages(pair_id,sender_id,message,time,seen) VALUES('".$pairid."','".$senderid."','".$message."','".$timestamp."','".$seen."')";
	$result=mysqli_query($connection,$query);
	echo json_encode(true);
	?>