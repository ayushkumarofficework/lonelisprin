<?php
	header('Content-type:application/json');
    $connection = mysqli_connect("localhost", "root" , "","lonelisprin");
	$userid=$_REQUEST['user_id'];
	$query="UPDATE lonelyusers SET lastseen='".$_SERVER['REQUEST_TIME']."' WHERE id='".$userid."'";
	$result=mysqli_query($connection,$query);
	echo json_encode("timestamp updated");
?>