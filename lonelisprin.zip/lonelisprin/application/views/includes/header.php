<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Lonelisprin</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" />
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" />
  <script src="../code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/jquery.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/materialize.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/jquery.sticky.js"></script>
    <script src="<?php echo $base_url; ?>/js/jquery.timeago.min.js"></script>  
    <script src="<?php echo $base_url; ?>/js/prism.js"></script>
    <script src="<?php echo $base_url; ?>/bin/materialize.js"></script>
    <script src="<?php echo $base_url; ?>/js/init.js"></script>
</head>
<body>
<div>

<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center">Logo</a>

	  </div>
  </nav>
  
</header>
</div>
<div>
<p align="right"><h5>hii <?php echo $this->session->userdata('name'); ?></h5></p>
</div>
</body>
<script>
  
  function messages(){
	  $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/newmessages',
		'dataType':'json',
		'success':function(result){
					$('#messagecount').html(result);
				}
		
	}); 
  }
  function updatetimestamp(){
	  $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/updatetimestamp',
		'dataType':'json',
		'success':function(result){
					if(result==true){$('#submitbtnfeedme').removeAttr('disabled');$('.feedmemessage').html('');}
					else{$('#submitbtnfeedme').attr('disabled','disabled');$('.feedmemessage').html('We are working hard to make ourselves available to your city.');}
				}
		
	});
  }
  function getnewmessages(){
	   $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/getnewmessages',
		'dataType':'json',
		'success':function(result){
					if(result){
						$('#newmessages').html('');
						
						for(var i=0;i<result.length;i++){
									$('#newmessages').prepend('<li><a href="<?php echo $base_url; ?>/index.php/chat?user_id='+result[i][0]+'">'+result[i][1]+'</a>'+
                                                      '</li>');	
						
								}
								$('#newmessages').prepend('<h5>New messages</h5>');
					}
				}
		
	}); 
  }
  function getoldmessages(){
	   $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/getoldmessages',
		'dataType':'json',
		'success':function(result){
					if(result){
						$('#oldmessages').html('');
						
						for(var i=0;i<result.length;i++){
									$('#oldmessages').prepend('<li><a href="<?php echo $base_url; ?>/index.php/chat?user_id='+result[i][0]+'">'+result[i][1]+'</a>'+
                                                      '</li>');	
						
								}
								$('#oldmessages').prepend('<h5>Old Messages</h5>');
					}
				}
		
	});
  }
  </script>
</html>