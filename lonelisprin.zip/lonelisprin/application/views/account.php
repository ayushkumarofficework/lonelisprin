<!DOCTYPE html>
<html lang="en">

<body onload="setInterval(updatetimestamp,30000),setInterval(messages,3000),messages()">
<header>
<div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only">
<i class="mdi-navigation-menu"></i></a></div>
<ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="" class="brand-logo">
            <h2>LOGO</h2></a></li>
        <li class="bold"><a href="<?php echo $base_url; ?>/index.php/peopleavailable" class="waves-effect waves-teal active">People Available</a></li>
        <li class="bold" id="messageslink"><a href="<?php echo $base_url; ?>/index.php/messages" class="waves-effect waves-teal">Messages<sup id="messagecount" style="color:red;"></sup></a></li>
		<li class="bold"><a href="<?php echo $base_url; ?>/index.php/home/logout" class="waves-effect waves-teal">Logout</a></li>
        
        
      </ul>
	  </header>
<main>
      <div class="section no-pad-bot" id="index-banner">
        <div class="container">
		<div class="row center">
            <h5>Welcome <?php echo $this->session->userdata('name')." "; ?>to</h5>
          </div>
          
          <h1 class="header center">Lonelisprin</h1>
          <div class='row center'>
            <h4 class ="header col s12  center">No need to feel lonely anymore!</h4>
          </div>
          

          
          <br>

        </div>
        
      </div>

      <div class="container">
        <div class="section">


          

          

        </div>
        <div class="divider"></div>
        
      </div>


    </main>
	</body>
	


  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  
  
  </html>
