<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <script src="../code.jquery.com/jquery-2.1.1.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.html"><\/script>'); }
    </script>
    <script src="js/jquery.timeago.min.js"></script>  
    <script src="js/prism.js"></script>
    <script src="bin/materialize.js"></script>
    <script src="js/init.js"></script>
</head>
<div>
<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper">
      <a href="<?php echo $base_url; ?>/index.php/home" class="brand-logo center">Logo</a>
      
    </div>
  </nav>
</header>
</div>
<body>
<header>
<div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only">
<i class="mdi-navigation-menu"></i></a></div>
<ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="" class="brand-logo">
            <h2>LOGO</h2></a></li>
        <li class="bold"><a href="timetableview.php" class="waves-effect waves-teal active">Show Timetable</a></li>
        
        
        
      </ul>
</header>
<main>
      <div class="container">
<div class="row center" style="aligh=center;">
        <div class="col s12 m12 ">
          <table  class="centered hoverable striped">
        <thead>
          <tr>
		  <th data-field="id">Day</th>
              <th data-field="id">1</th>
			   <th data-field="id">2</th>
			    <th data-field="id">3</th>
				 <th data-field="id">4</th>
				  <th data-field="id">5</th>
			   <th data-field="id">6</th>
			    <th data-field="id">7</th>
				 <th data-field="id">8</th>
             
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>Mon</td>
            <td>dbms</td>
            <td>toc</td>
			 <td>mip</td>
			 
			  
			  
			  <td>---</td><td>software</td>
			   
			    <td>---</td>
				 <td>---</td>
				 <td>---</td>
          </tr>
          <tr>
             <td>Tue</td>
            <td>dbms</td>
            <td>toc</td>
			 <td>mip</td>
			 <td>Dc</td>
			  <td>software</td>
			   
			    <td>---</td>
				 <td>---</td>
				 <td>---</td>
          </tr>
          <tr>
             <td>Wed</td>
            <td>dbms</td>
            <td>toc</td>
			 <td>mip</td>
			 <td>Dc</td>
			  <td>software</td>
			   
			    <td>---</td>
				 <td>---</td>
				 <td>---</td>
          </tr>
		  <tr>
             <td>Thu</td>
            <td>dbms</td>
            <td>toc</td>
			 <td>mip</td>
			  <td>Dc</td>
			  <td>software</td>
			   
			    <td>---</td>
				 <td>---</td>
				 <td>---</td>
          </tr>
		  <tr>
             <td>Fri</td>
            <td>---</td>
            <td>---</td>
			<td>Dc</td>
			 <td>---</td>
			  <td>---</td>
			   
			    <td>---</td>
				 <td>---</td>
				 <td>---</td>
          </tr>
        </tbody>
      </table>
	  
        </div>
		
      </div>
	  
</div>	 
<div class="container">
<div class="row center"
    <div style="padding-top=50px;">
            <a class="waves-effect waves-light btn" href="#">Print</a>
			
			</div>
			</div>
</div> 

    </main>