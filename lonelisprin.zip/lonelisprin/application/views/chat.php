<html>
<body onload="myfunction(),updatemessages(),showmessages(<?php echo $this->session->userdata('userid'); ?>)">
<br>
<h6><b><?php echo $usertalkingto; ?></b></h6>
 <div class="row">
    
      <div class="row">
        <div class="input-field col s12 l8" style="left:60px;" >
          <textarea id="message" class="materialize-textarea"></textarea>
          <label for="textarea1">Click to type</label>
        </div>
      </div>
    <a class="waves-effect waves-light btn" style="left:70px;" onclick="sendmessage()">SEND</a>
  </div>
  <div>
    <ul id="messages">
	
	</ul>
  </div>
<script>
  
    function myfunction(){
	var c;
	c=setInterval(updatetimestamp,15000);
    }
	function showmessages(userid){
		$.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/showmessages',
		'dataType':'json',
		'success':function(result){
			if(result){
				$('#messages').html('');
				//var userid=<?php echo $this->session->userdata('userid'); ?>
				//System.out(userid);
				//alert(userid);
				for(var i=0;i<result.length;i++){
					if(userid==result[i][2]){
						$('#messages').prepend('<li><div style=" background:yellow; width:300px;margin-left:60%;"><b><p align="right" color="white">'+result[i][3]+''+
                                                      '</p></b></div></li>');
					}
					else{
						$('#messages').prepend('<li><div style=" background:#e8eaf6; width:300px;"><b><p align="left" color="white">'+result[i][3]+''+
                                                      '</p></b><div></li>');
					}
										
						
				}
				
			}
			       
			
		}
		
		});
	}
	function updatemessages(){
		var d;
		d=setInterval(messagelist,3000);
	}
	function messagelist(){
		showmessages(<?php echo $this->session->userdata('userid'); ?>);
	}
	function sendmessage(){
		var message=$('#message').val();
		if(message.length>0){
		$.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/sendmessage',
		'dataType':'json','type':'post',
		'data':{"message":message},
		'success':function(result){
			        $('#message').val('');
					Materialize.toast('message sent', 4000)
					showmessages(<?php echo $this->session->userdata('userid'); ?>);
				}
		
		});}
		else{
			Materialize.toast('message box is empty', 4000)
		}
	}
</script>
