<html>
<body onload="setInterval(updatetimestamp,15000),getnewmessages(),setInterval(getnewmessages,30000),getoldmessages(),setInterval(getoldmessages,30000)">
<ul id="newmessages">

</ul>
<ul id="oldmessages">

</ul>
</body>
</html>
