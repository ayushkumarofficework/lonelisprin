<html>
<body onload="myfunction(),myFunction()">
<div>
    <ul id="onlinepeople">
	<?php if($onlinepeople){ ?> 
	<h4>Online People</h4>
	<?php foreach($onlinepeople as $people) { ?>
    <li><b><a style="color:#00ff00;" href="<?php echo $base_url; ?>/index.php/chat?user_id=<?php echo $people['id']; ?>"><?php echo $people['name']; ?></a>
                                                      </b></li>
	<?php } ?>
    
	<?php } ?>
  </ul>
  </div>
  <br>
  <div>
    <ul id="restofthepeople">
	<?php if($restofthepeople){ ?> 
	<h4>Other People</h4>
	<?php foreach($restofthepeople as $people) { ?>
    <li><a href="<?php echo $base_url; ?>/index.php/chat?user_id=<?php echo $people['id']; ?>"><?php echo $people['name']; ?></a>
                                                      </li>
	<?php } ?>
    
	<?php } ?>
  </ul>
  </div>
</body>
<script>

function myfunction(){
	var c;
	c=setInterval(updatetimestamp,15000);
}
function myFunction(){
	var a,b;
	a=setInterval(onlinepeople,30000);
	b=setInterval(restofthepeople,30000);
}
function onlinepeople(){
	 $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/getonlinepeople',
		'dataType':'json',
		'success':function(result){
					if(result){
						$('#onlinepeople').html('');
						$('#onlinepeople').append('<h4>Online People</h4>');
						for(var i=0;i<result.length;i++){
									$('#onlinepeople').append('<li><b><a style="color:#00ff00;" href="<?php echo $base_url; ?>/index.php/chat?user_id='+result[i][0]+'">'+result[i][1]+'</a>'+
                                                      '</b></li>');	
						
								}
					}
					else{}
				}
		
	});
}
function restofthepeople(){
	 $.ajax({
		'url':'<?php echo $base_url;?>/index.php/ajax/getrestofthepeople',
		'dataType':'json',
		'success':function(result){
			            if(result){
						$('#restofthepeople').html('');
						$('#restofthepeople').append('<h4>Other People</h4>');
						for(var i=0;i<result.length;i++){
									$('#restofthepeople').append('<li><a href="<?php echo $base_url; ?>/index.php/chat?usre_id='+result[i][0]+'">'+result[i][1]+'</a>'+
                                                      '</li>');	
						
								}
					}
					else{}
				}
		
	});
}
</script>
</html>