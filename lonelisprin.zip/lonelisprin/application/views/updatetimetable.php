<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <script src="../js/jquery.min.js"></script>
    <script>if (!window.jQuery) { document.write('<script src="bin/jquery-2.1.1.min.html"><\/script>'); }
    </script>
    <script src="<?php echo $base_url; ?>/js/jquery.timeago.min.js"></script>  
    <script src="<?php echo $base_url; ?>/js/prism.js"></script>
    <script src="<?php echo $base_url; ?>/js/materialize.js"></script>
    <script src="<?php echo $base_url; ?>/js/init.js"></script>
</head>
<div>
<header>
<nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center">Logo</a>
      
    </div>
  </nav>
</header>
</div>
<body>
<header>
<div class="container"><a href="#" data-activates="nav-mobile" class="button-collapse top-nav waves-effect waves-light circle hide-on-large-only">
<i class="mdi-navigation-menu"></i></a></div>
<!--ul id="nav-mobile" class="side-nav fixed">
        <li class="logo"><a id="logo-container" href="<!--?php echo $base_url; ?>" class="brand-logo">
            <h2>LOGO</h2></a></li>
        <li class="bold"><a href="<!--?php echo $base_url; ?>/index.php/createtimetable" class="waves-effect waves-teal active">Create Timetable</a></li>
        <li class="bold"><a href="<!--?php echo $base_url; ?>/index.php/showtimetablepresent" class="waves-effect waves-teal">Show Timetable</a></li>
        <li class="bold"><a href="#" class="waves-effect waves-teal">Update Timetable</a></li>
        <li class="bold"><a href="<!--?php echo $base_url; ?>/index.php/home/logout" class="waves-effect waves-teal">Logout</a></li>
        
      </ul-->
</header>
<main>
      <div class="container">
<div class="row center">
        <div class="col s12 m12">
          <div class="card">
            <div class="card-content black-text">
              <span class="card-title">Update Credentials</span>
              <p><div class="container"><div class="row center">
                    
  <div class="row">
  <?php if($timetabletobeupdated){ ?>
    <form class="col s12" action="<?php echo $base_url; ?>/index.php/updatetimetable/update" method="post">
	<div class="container">
      <div class="row center">
        
		
        
      </div></div>
	  <?php $numberofsubjects=$this->session->userdata('numberofsubjects');
	  $i=1;
	  foreach($timetabletobeupdated as $timetable){ ?>
      <div class="row">
        <div class="input-field col s2">
          <input  placeholder="Teacher code" name="teachercode<?php echo $i; ?>" value="<?php echo $timetable['teacher_code']; ?>" type="text" class="validate">
          
        </div>
		<div class="input-field col s4">
          <input  placeholder="Teacher name" name="teachername<?php echo $i; ?>" value="<?php echo $timetable['teacher_name']; ?>" type="text" class="validate">
          
        </div>
		<div class="input-field col s3">
          <input  placeholder="Subject" name="subject<?php echo $i; ?>" type="text" value="<?php echo $timetable['subject']; ?>"class="validate">
          
        </div>
		<div class="input-field col s3">
          <input  placeholder="No of class a week" name="numberofclassesaweek<?php echo $i; ?>" type="number" value="<?php $busytime=trim($timetable['teacher_busy_time']);
		  $busy[]=array();
		  $busy=explode(" ",$busytime); 
		  echo sizeof($busy);?>" class="validate">
          
        </div>
      </div>
	  <?php $i++; } ?>
	  
	  <div class="card-action">
              <input type="submit" class="waves-effect waves-light btn" value="UPDATE TIMETABLE">
              
            </div>
	
      
    </form>
	<div class="card-action">
              <a href="<?php echo $base_url; ?>/index.php/home" class="waves-effect waves-light btn orange">CANCEL</a>
              
            </div>
			<div class="card-action">
              <a href="<?php echo $base_url; ?>/index.php/updatetimetable/deletetimetable" onclick="Materialize.toast('Timetable is now deleted , You can create a new one!', 4000)" class="waves-effect waves-light btn red">DELETE</a>
              
            </div>
  <?php }else { ?>
  </div>
               </div></div>
        </p>
            </div>
            
          </div>
        </div>
      </div>
</div>
<p align="center">You have not created any timetable!</p>
  <?php } ?>	  

    </main>
	<script>
	 $(document).ready(function(){
    $('.tooltipped').tooltip({delay: 5000});
  });
	</script>
	</body>