<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Easy Timetable</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="<?php echo $base_url; ?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="<?php echo $base_url; ?>/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo">Logo</a>
      <ul class="right hide-on-med-and-down">
        <li><a href="#">Navbar Link</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="#">Navbar Link</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
    <div class="container">
<div class="row center">
        <div class="col s12 m12">
          <div class="card">
            <div class="card-content black-text">
              <span class="card-title">Enter semester</span>
              <p><div class="container"><div class="row center">
                    
  <div class="row"  >
    <form class="col s12"  action="<?php echo $base_url; ?>/index.php/viewtimetable/viewbysemester" method="post">
	<div class="container">
      <div class="row center">
        
		<div class="input-field col s12" >
          <input placeholder="Semester" id="numberofsubjects" name="semester" type="number" class="validate">
          
        </div>
        
      </div></div>
	  
      <div>
             <input type="submit" class="waves-effect waves-light btn" value="VIEW TIMETABLE" /> 
              
            </div>
    </form>
  </div>
               </div></div>
        </p>
            </div>
            
          </div>
        </div>
      </div>
</div>
  </body>