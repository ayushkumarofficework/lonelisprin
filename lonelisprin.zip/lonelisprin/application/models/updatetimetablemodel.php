<?php 
class Updatetimetablemodel extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	function deletePreviousRecords(){
		$semester=$this->session->userdata('semester');
		$result=$this->db->query("SELECT * FROM teacherbysemester WHERE semester='".$semester."'");
		$rows=$result->result_array();
		if($semester%2==0){
		foreach($rows as $row){
			$totalbusytime=$this->db->query("SELECT * FROM teacherseven WHERE teacher_code='".$row['teacher_code']."'");
			$totalbusytimearray=$totalbusytime->result_array();
			$tempbusytime=trim($row['teacher_busy_time']);
			$busytime[]=array();
			$busytime=explode(" ",$tempbusytime);
			$tempbusytime=implode("",$busytime);
			foreach($totalbusytimearray as $busytimetobeupdated){
			$busytime=$busytimetobeupdated['teacher_busy_time'];$busytime=str_replace($tempbusytime,"",$busytime);
			$this->db->query("UPDATE teacherseven SET teacher_busy_time='".$busytime."' WHERE teacher_code='".$row['teacher_code']."'");
			}
		}
		$this->db->query("DELETE FROM teacherbysemester WHERE semester='".$semester."'");
		$this->db->query("DELETE FROM timetable WHERE semester='".$semester."'");
		return true;
		}
		else{
			foreach($rows as $row){
			$totalbusytime=$this->db->query("SELECT * FROM teachersodd WHERE teacher_code='".$row['teacher_code']."'");
			$totalbusytimearray=$totalbusytime->result_array();
			$tempbusytime=trim($row['teacher_busy_time']);
			$busytime[]=array();
			$busytime=explode(" ",$tempbusytime);
			$tempbusytime=implode("",$busytime);
			foreach($totalbusytimearray as $busytimetobeupdated){
			$busytime=$busytimetobeupdated['teacher_busy_time'];$busytime=str_replace($tempbusytime,"",$busytime);
			$this->db->query("UPDATE teachersodd SET teacher_busy_time='".$busytime."' WHERE teacher_code='".$row['teacher_code']."'");
			}
		}
		$this->db->query("DELETE FROM teacherbysemester WHERE semester='".$semester."'");
		$this->db->query("DELETE FROM timetable WHERE semester='".$semester."'");
		return true;
		}
	}
}