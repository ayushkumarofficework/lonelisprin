<?php class Peoplemodel extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	function onlinepeople(){
		$timestamp=$_SERVER['REQUEST_TIME'];
		$timestamp-=30;
		$userid=$this->session->userdata('userid');
		$result=$this->db->query("SELECT * FROM lonelyusers WHERE lastseen>='".$timestamp."' AND id <>'".$userid."'");
		if($result->num_rows()>0){
			return $result->result_array();
		}
		else
		{
			$e="";
			return $e;
		}
	}
	function restofthepeople(){
		$timestamp=$_SERVER['REQUEST_TIME'];
		$timestamp-=30;
		$userid=$this->session->userdata('userid');
		$result=$this->db->query("SELECT * FROM lonelyusers WHERE lastseen<'".$timestamp."' AND id <>'".$userid."'");
		if($result->num_rows()>0){
			return $result->result_array();
		}
		else
		{
			$e="";
			return $e;
		}
	}
}