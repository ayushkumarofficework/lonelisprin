<?php
class Showtimetablemodel extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	function getTimetable(){
		$semester=$this->session->userdata('semester');
		$result=$this->db->query("SELECT * FROM timetable WHERE semester='".$semester."'");
		return $result->result_array();
	}
	function getTimetableBySemester(){
		$semester=$this->input->post('semester');
		$result=$this->db->query("SELECT * FROM timetable WHERE semester='".$semester."'");
		return $result->result_array();
	}
	function getTimetableData(){
		$semester=$this->session->userdata('semester');
		$result=$this->db->query("SELECT * FROM teacherbysemester WHERE semester='".$semester."'");
		return $result->result_array();
	}
}