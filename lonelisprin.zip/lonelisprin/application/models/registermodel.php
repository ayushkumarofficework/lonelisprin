<?php 
class Registermodel extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	function registerNewUser(){
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		//$semester=$this->input->post('semester');
		//$branch=$this->input->post('branch');
		$password=$this->input->post('password');
		$sql="INSERT INTO `lonelyusers` (name,email,password,lastseen) VALUES(
		'".$name."',
		'".$email."',
		'".$password."',
		'".$_SERVER['REQUEST_TIME']."')";
		$this->db->query($sql);
		if($this->db->affected_rows())
		{   $this->session->set_userdata('name',$name);
	        $this->session->set_userdata('email',$email);
	       // $this->session->set_userdata('branch',$branch);
	       // $this->session->set_userdata('semester',$semester);
			$this->session->set_userdata('logged_in',true);
			$sql="SELECT * FROM lonelyusers WHERE email='".$email."'";
			$result=$this->db->query($sql);
			$row=$result->row();
			$userid=$row->id;
			$this->session->set_userdata('userid',$userid);
			return $name;
		}
		else
			return "";
	}
	function loginUser(){
		$loginemail=$this->input->post('loginemail');
		$loginpassword=$this->input->post('loginpassword');
		$sql="SELECT * FROM lonelyusers WHERE email='".$loginemail."'";
		$result=$this->db->query($sql);
		$row=$result->row();
		if($result->num_rows()==1){
			if($row->password==$loginpassword){
				$sess_data=array(
		            'name' => $row->name,
		            
		            'email' => $loginemail,
					'userid'=> $row->id,
		            'logged_in' => true);
				$this->session->set_userdata($sess_data);
				$this->db->query("UPDATE lonelyusers SET lastseen='".$_SERVER['REQUEST_TIME']."' WHERE email='".$loginemail."'");
				return 'logged_in';
			}
			else 
				return 'incorrect_password';
		}
		else
			return 'email_not_found';
	}
}