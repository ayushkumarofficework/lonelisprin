<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php class Chat extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if(!$this->session->has_userdata('logged_in')){
			redirect($data['base_url']);
		}
		
		$this->load->view('includes/header',$data);
		$recieverid=$this->input->get('user_id');
		$userid=$this->session->userdata('userid');
		if($recieverid==$userid)
			redirect($data['base_url']."/index.php/messages");
		$result=$this->db->query("SELECT * FROM lonelypairs WHERE (first_user_id='".$userid."' AND second_user_id='".$recieverid."') OR (first_user_id='".$recieverid."' AND second_user_id='".$userid."')");
		if($result->num_rows()>0){
			$row=$result->row();
			$this->session->set_userdata('chatpairid',$row->pair_id);
		}
		else{
			$this->db->query("INSERT INTO lonelypairs(first_user_id,second_user_id) VALUES ('".$userid."','".$recieverid."')");
			if($this->db->affected_rows()){
				$result=$this->db->query("SELECT * FROM lonelypairs WHERE (first_user_id='".$userid."' AND second_user_id='".$recieverid."') OR (first_user_id='".$recieverid."' AND second_user_id='".$userid."')");
				$row=$result->row();
				$this->session->set_userdata('chatpairid',$row->pair_id);
			}
		}
		$result=$this->db->query("SELECT * FROM lonelyusers WHERE id='".$recieverid."'");
		$row=$result->row();
		$data['usertalkingto']=$row->name;
		$this->load->view('chat',$data);
	}
}