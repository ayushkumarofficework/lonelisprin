<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php class Messages extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if(!$this->session->has_userdata('logged_in')){
			redirect($data['base_url']);
		}
		//$this->load->model('messagesmodel');
		//$data['newmessages']=$this->messagesmodel->getnewmessages();
		$this->load->view('includes/header',$data);
		$this->load->view('messages');
	}
}