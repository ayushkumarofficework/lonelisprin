<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
class Login extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if($this->session->userdata('logged_in')==true)
			redirect($data['base_url']."/index.php/home");
		else
		$this->load->view('login',$data);
	}
}