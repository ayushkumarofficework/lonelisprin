<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php class Peopleavailable extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		if(!$this->session->has_userdata('logged_in'))
		{
			redirect($data['base_url']);
		}
		$this->load->view('includes/header',$data);
		$this->load->model('peoplemodel');
		$data['onlinepeople']=$this->peoplemodel->onlinepeople();
		$data['restofthepeople']=$this->peoplemodel->restofthepeople();
		$this->load->view('peopleavailable',$data);
	}
}
?>