<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Ajax extends CI_Controller{
	public function assignNumberofsubjects(){
		$numberofsubjects=$this->input->post('numberofsubjects');
		$this->session->set_userdata('numberofsubjects',$numberofsubjects);
		echo ($numberofsubjects);
	}
	public function updatetimestamp(){
		$email=$this->session->userdata('email');
		$this->db->query("UPDATE lonelyusers SET lastseen='".$_SERVER['REQUEST_TIME']."' WHERE email='".$email."'");
		echo "true";
	}
	public function getonlinepeople(){
		$timestamp=$_SERVER['REQUEST_TIME'];
		$userid=$this->session->userdata('userid');
		$timestamp=$timestamp-30;
			$result=$this->db->query("SELECT * FROM lonelyusers WHERE lastseen>='".$timestamp."' AND id <>'".$userid."'");
		if($result->num_rows()>0){
		$row=$result->result_array();
		$ans[]=array();$i=0;//add restriction of pincode
		foreach($row as $abc){
			$ans[$i][0]=$abc['id'];
			$ans[$i][1]=$abc['name'];
			$ans[$i][2]=$abc['email'];
			$i++;
		}
	echo json_encode($ans);
	}
	else echo "false";
	}
	
	public function getrestofthepeople(){
		$timestamp=$_SERVER['REQUEST_TIME'];
		$userid=$this->session->userdata('userid');
		$timestamp=$timestamp-30;
			$result=$this->db->query("SELECT * FROM lonelyusers WHERE lastseen<'".$timestamp."' AND id <>'".$userid."'");
		if($result->num_rows()>0){
		$row=$result->result_array();
		$ans[]=array();$i=0;//add restriction of pincode
		foreach($row as $abc){
			$ans[$i][0]=$abc['id'];
			$ans[$i][1]=$abc['name'];
			$ans[$i][2]=$abc['email'];
			$i++;
		}
	echo json_encode($ans);
	}
	else echo "false";
	}
	public function sendmessage(){
		$message=$this->input->post('message');
		$pairid=$this->session->userdata('chatpairid');
		$senderid=$this->session->userdata('userid');
		$seen=";".$senderid.";";
		$timestamp=$_SERVER['REQUEST_TIME'];
		$this->db->query("INSERT INTO lonelymessages(pair_id,sender_id,message,time,seen) VALUES('".$pairid."','".$senderid."','".$message."','".$timestamp."','".$seen."')");
		if($this->db->affected_rows()){
			echo true;
		}
		else
			echo false;
	}
	public function showmessages(){
		$pairid=$this->session->userdata('chatpairid');
		$userid=$this->session->userdata('userid');
		//$seen=";".$userid.";";
		$result=$this->db->query("SELECT * FROM lonelymessages WHERE pair_id='".$pairid."'");
		if($result->num_rows()>0){
		$row=$result->result_array();
		$ans[]=array();$i=0;//add restriction of pincode
		foreach($row as $abc){
			$ans[$i][0]=$abc['message_id'];
			$ans[$i][1]=$abc['pair_id'];
			$ans[$i][2]=$abc['sender_id'];
			$ans[$i][3]=$abc['message'];
			$ans[$i][4]=$abc['seen'];
			$seen=";".$userid.";";
			if(strpos($abc['seen'],$seen)===false){
				$seen=$seen.$abc['seen'];
				$this->db->query("UPDATE lonelymessages SET seen='".$seen."' WHERE message_id='".$abc['message_id']."'");
			}
			else{
				
			}
			//$ans[$i][3]=$abc['message'];
			$i++;
		}
	echo json_encode($ans);
	}
	}
	public function newmessages(){
		$userid=$this->session->userdata('userid');
		$seen=";".$userid.";";
		$result=$this->db->query("SELECT DISTINCT(pair_id) FROM lonelymessages WHERE seen NOT LIKE '%".$seen."%' AND pair_id IN(SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))");
		$row=$result->num_rows();
		echo $row;
	}
	public function getnewmessages(){
		$userid=$this->session->userdata('userid');
		$seen=";".$userid.";";
		$result=$this->db->query("SELECT * FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen NOT LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' ");
		if($result->num_rows()>0){
		$row=$result->result_array();
		$ans[]=array();$i=0;//add restriction of pincode
		foreach($row as $abc){
			$ans[$i][0]=$abc['id'];
			$ans[$i][1]=$abc['name'];
			$ans[$i][2]=$abc['email'];
			$i++;
		}
		echo json_encode($ans);
		}
        else{
			echo "false";
		}	
	}
	public function getoldmessages(){
		$userid=$this->session->userdata('userid');
		$seen=";".$userid.";";//add not in constraint
		$result=$this->db->query("SELECT * FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' AND id NOT IN (SELECT id FROM lonelyusers WHERE id IN (SELECT DISTINCT(sender_id) FROM lonelymessages WHERE seen NOT LIKE '%".$seen."%' AND pair_id IN (SELECT pair_id FROM lonelypairs WHERE (first_user_id='".$userid."') OR (second_user_id='".$userid."'))) AND id <>'".$userid."' )");
		if($result->num_rows()>0){
		$row=$result->result_array();
		$ans[]=array();$i=0;//add restriction of pincode
		foreach($row as $abc){
			$ans[$i][0]=$abc['id'];
			$ans[$i][1]=$abc['name'];
			$ans[$i][2]=$abc['email'];
			$i++;
		}
		echo json_encode($ans);
		}
        else{
			echo "false";
		}
	}
}
?>