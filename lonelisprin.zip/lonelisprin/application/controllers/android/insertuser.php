<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php class Insert_user extends CI_Controller{
	function index(){
		$email=$this->input->post('email');
		$name=$this->input->post('name');
		$password=$this->input->post('password');
		$query="INSERT INTO lonelyusers(name,email,password,lastseen) VALUES('".$name."','".$email."','".$password."','".$_SERVER['REQUEST_TIME']."')";
		 mysql_query($query) ;
		
			echo true;
		
	}
}