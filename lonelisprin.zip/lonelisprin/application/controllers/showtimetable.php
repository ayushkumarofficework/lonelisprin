<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php 
class Showtimetable extends CI_Controller{
	function index(){
		$data['base_url']=$this->config->item('base_url');
		$numberofsubjects=$this->session->userdata('numberofsubjects');
		$teachercode[]=array();
		$teachername[]=array();
		$subject[]=array();
		$numberofclassesaweek[]=array();
		$teacherbusytime[]=array();
		$teachertemporarybusytime[]=array();
		for($i=1;$i<=$numberofsubjects;$i++){
			$teachercode[$i]=$this->input->post('teachercode'.$i);
			$teachername[$i]=$this->input->post('teachername'.$i);
			$subject[$i]=$this->input->post('subject'.$i);
			$numberofclassesaweek[$i]=$this->input->post('numberofclassesaweek'.$i);
		}
		$count[]=array();
		for($i=1;$i<=$numberofsubjects;$i++){
			$count[$i]=true;
			$teachertemporarybusytime[$i]="";
		}
		$branch=$this->session->userdata('branch');
		if($this->session->userdata('semester')%2==0){
		for($i=1;$i<=$numberofsubjects;$i++){
			$teacherbusytime[$i]="";
			$result=$this->db->query("SELECT * FROM teacherseven WHERE teacher_code LIKE '".$teachercode[$i]."'");
			if($result->num_rows()==0){
				$this->db->query("INSERT INTO teacherseven(teacher_code,teacher_name,teacher_busy_time) VALUES ('".
				$teachercode[$i]."','".$teachername[$i]."','".$teacherbusytime[$i]."')");
			}
			else{
				$rows=$result->result_array();
				foreach($rows as $row){
				$teacherbusytime[$i]=$row['teacher_busy_time'];	
				}
				
			}
		}
		}
		else{
			for($i=1;$i<=$numberofsubjects;$i++){
			$teacherbusytime[$i]="";
			$result=$this->db->query("SELECT * FROM teachersodd WHERE teacher_code='".$teachercode[$i]."'");
			if($result->num_rows()==0){
				$this->db->query("INSERT INTO teachersodd(teacher_code,teacher_name,teacher_busy_time) VALUES ('".
				$teachercode[$i]."','".$teachername[$i]."','".$teacherbusytime[$i]."')");
			}
			else{
				$row=$result->result_array();
				foreach($rows as $row){
				$teacherbusytime[$i]=$row['teacher_busy_time'];	
				}
			}
		}
		}
		$semester=$this->session->userdata('semester');
	    {
			if($semester==1){
				//for first semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teachersodd SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','1','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','1','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','1','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','1','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','1','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','1','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==2){
				//for second semester
								//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teacherseven SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','2','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','2','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','2','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','2','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','2','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','2','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==3){
				//for third semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teachersodd SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','3','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','3','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','3','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','3','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','3','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','3','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==4){
				//for fourth semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teacherseven SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','4','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','4','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','4','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','4','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','4','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','4','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
			    //$this->load->view('showtimetable',$data);
			}
			if($semester==5){
				//for fifth semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teachersodd SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','5','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','5','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','5','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','5','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','5','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','5','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==6){
				//for sixth semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teacherseven SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','6','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','6','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','6','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','6','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','6','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','6','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==7){
				//for seventh semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teachersodd SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','7','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','7','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','7','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','7','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','7','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','7','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
			if($semester==8){
				//for eighth semester
				//for monday
				//$mon['period1']="---";
				//$mon['period2']="---";
				for($j=1;$j<=8;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$mon['period'.$j]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$mon['period'.$j]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for tuesday
				//$tue['period1']="---";
				//$tue['period2']="---";
				for($j=9;$j<=16;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$tue['period'.($j-8)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$tue['period'.($j-8)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for wednesday
				//$wed['period1']="---";
				//$wed['period2']="---";
				for($j=17;$j<=24;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$wed['period'.($j-16)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$wed['period'.($j-16)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for thursday
				//$thu['period1']="---";
				//$thu['period2']="---";
				for($j=25;$j<=32;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$thu['period'.($j-24)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$thu['period'.($j-24)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$count[$i]=true;
				}
				//for fri
				//$fri['period1']="---";
				//$fri['period2']="---";
				for($j=33;$j<=40;$j++){
					for($i=1;$i<=$numberofsubjects;$i++){
						if(strpos($teacherbusytime[$i],";".$j.";")==false){
							if($numberofclassesaweek[$i]>0&&$count[$i]==true){
							$fri['period'.($j-32)]=$subject[$i]." ".$teachername[$i];
							$teachertemporarybusytime[$i]=$teachertemporarybusytime[$i]." ;".$j.";";
							$teacherbusytime[$i]=$teacherbusytime[$i].";".$j.";";
							$count[$i]=false;
							$numberofclassesaweek[$i]--;
							break;
							}
							else{
								$fri['period'.($j-32)]="---";
							}
						}
					}
				}
				for($i=1;$i<=$numberofsubjects;$i++){
					$this->db->query("UPDATE teacherseven SET teacher_busy_time='".$teacherbusytime[$i]."' WHERE teacher_code='".$teachercode[$i]."'");
					$this->db->query("INSERT INTO `teacherbysemester` (teacher_code,teacher_name,subject,semester,teacher_busy_time) VALUES ('".$teachercode[$i]."','".$teachername[$i]."','".$subject[$i]."','8','".$teachertemporarybusytime[$i]."')");
				}
				for($i=1;$i<=5;$i++){
					if($i==1){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','8','Mon','".$mon['period1']."','".$mon['period2']."','".$mon['period3']."','".$mon['period4']."','".$mon['period5']."','".$mon['period6']."','".$mon['period7']."','".$mon['period8']."')");
					}
					if($i==2){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','8','Tue','".$tue['period1']."','".$tue['period2']."','".$tue['period3']."','".$tue['period4']."','".$tue['period5']."','".$tue['period6']."','".$tue['period7']."','".$tue['period8']."')");
					}
					if($i==3){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','8','Wed','".$wed['period1']."','".$wed['period2']."','".$wed['period3']."','".$wed['period4']."','".$wed['period5']."','".$wed['period6']."','".$wed['period7']."','".$wed['period8']."')");
					}
					if($i==4){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','8','Thu','".$thu['period1']."','".$thu['period2']."','".$thu['period3']."','".$thu['period4']."','".$thu['period5']."','".$thu['period6']."','".$thu['period7']."','".$thu['period8']."')");
					}
					if($i==5){
						$this->db->query("INSERT INTO `timetable` (branch,semester,day,period1,period2,period3,period4,period5,period6,period7,period8) VALUES ('".$branch."','8','Fri','".$fri['period1']."','".$fri['period2']."','".$fri['period3']."','".$fri['period4']."','".$fri['period5']."','".$fri['period6']."','".$fri['period7']."','".$fri['period8']."')");
					}
				}
				
			}
		}
		
		$this->load->model('showtimetablemodel');
		$data['timetable']=$this->showtimetablemodel->getTimetable();
		
		$this->load->view('showtimetable',$data);
	}
}
?>